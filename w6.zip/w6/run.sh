#!/bin/bash

# Initialise the centroids for the first K-means iteration
cp initial_centroids_backup.txt centroids.txt

i=1
while :
do
    # Prepare the HDFS output dir for this iteration
    hadoop fs -rm -r -f /mapreduce-output$i

    # Run the job using one reducer
    hadoop jar /usr/lib/hadoop/hadoop-streaming.jar \
    -D mapreduce.job.reduces=1 \
    -files centroids.txt,mapper.py,reducer.py \
    -mapper ./mapper.py \
    -reducer ./reducer.py \
    -input /dataset.txt \
    -output /mapreduce-output$i
        
    # Copy the new centroids from HDFS to the local node for convergence checking
    hadoop fs -copyToLocal /mapreduce-output$i/part-00000 centroids1.txt
    # Simply display the old and new centroids so we can compare them and check whether K-means has converged
    echo "=== old ==="
    cat centroids.txt
    echo "=== new==="
    cat centroids1.txt
	
    seeiftrue=`python reader.py` 
    # If convergence is reached, update the centroids, and stop. 
    # Otherwise, the new centroids become the centroids for the next iterataion. 
    if [ $seeiftrue = 1 ]
    then
        mv centroids1.txt centroids.txt
	break
    else
	mv centroids1.txt centroids.txt
    fi
    i=$((i+1))
done

